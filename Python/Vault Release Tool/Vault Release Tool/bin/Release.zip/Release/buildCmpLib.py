﻿import cmpLib_ipy


cmpLib_ipy.buildCmpLib(crPath, cmpLibPath, crType, vaultAddress, userName, pwd )