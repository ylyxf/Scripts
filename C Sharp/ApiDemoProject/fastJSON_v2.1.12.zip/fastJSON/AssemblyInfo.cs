﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("fastJSON")]
[assembly: AssemblyDescription("smallest fastest polymorphic json serializer")]
[assembly: AssemblyProduct("fastJSON")]
[assembly: AssemblyCopyright("2010-2014")]


[assembly: AssemblyVersion("2.1.0.0")]
[assembly: AssemblyFileVersion("2.1.12.0")]
